# Reflection

Using `@property` makes the code easier to read because I can access the getter and setter like regular variables. Instead of using methods like `get_width()` and `set_width()`, I can use `rectangle.width` and `rectangle.width = value`. This makes the code cleaner and easier to understand.
